package data.campaign.econ;

public class dcp_magellan_ConditionData {
   public static final float STABILITY_MAGELLAN_WARRENS_BONUS = 1.0F;
   public static final float STABILITY_MAGELLAN_WARRENS_PENALTY = -2.0F;
}
