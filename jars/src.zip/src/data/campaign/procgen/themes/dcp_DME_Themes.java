package data.campaign.procgen.themes;

public class dcp_DME_Themes {
   public static final String BREAKERS = "breakers";
}
