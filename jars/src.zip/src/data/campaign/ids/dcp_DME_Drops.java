package data.campaign.ids;

public class dcp_DME_Drops {
   public static final String SIGMA_MATTER_ADV = "dcp_DME_sigma_matter2";
   public static final String SIGMA_MATTER_PRIM = "dcp_DME_sigma_matter1";
   public static final String BREAKER_WEAPONS_LG = "dcp_DME_breaker_weapons_large";
   public static final String BREAKER_WEAPONS_MED = "dcp_DME_breaker_weapons_medium";
   public static final String BREAKER_WEAPONS_SM = "dcp_DME_breaker_weapons_small";
   public static final String BREAKER_FIGHTERS = "dcp_DME_breaker_fighters";
}
