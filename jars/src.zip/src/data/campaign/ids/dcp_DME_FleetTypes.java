package data.campaign.ids;

public class dcp_DME_FleetTypes {
   public static final String BATTLESTATION = "dcp_DME_battlestation";
}
