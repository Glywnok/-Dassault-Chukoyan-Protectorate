package data.campaign.ids;

public class dcp_DME_Commodities {
   //DME
   public static final String SIGMA_MATTER = "dcp_DME_sigma_matter";
   public static final String SIGMA_MATTER_HIGH = "dcp_DME_sigma_matter2";
   public static final String SIGMA_MATTER_LOW = "dcp_DME_sigma_matter1";
   public static final String SIGMA_MATTER_UNSTABLE = "dcp_DME_sigma_matter3";
   public static final String SECURE_DATA_BOX = "dcp_DME_securedata";

   //Magellan
   public static final String MAGELLAN_CITYWARRENS = "dcp_magellan_warrens";
}
