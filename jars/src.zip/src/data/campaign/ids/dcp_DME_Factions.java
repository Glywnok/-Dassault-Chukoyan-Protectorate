package data.campaign.ids;

public class dcp_DME_Factions {
   //DME
   public static final String DASSAULT = "dassault_mikoyan";
   public static final String SIXEME_BUREAU = "6eme_bureau";
   public static final String BREAKERS = "blade_breakers";


   //Magellan
   public static final String MG_PROTECTORATE = "magellan_protectorate";
   public static final String MG_LEVELLERS = "magellan_leveller";
   public static final String MG_SKYTIGER = "magellan_startigers";
   public static final String MG_HERD = "magellan_theherd";
   public static final String MG_INDIE_FOR_MARKET = "magellan_independentmkt";
   public static final String MG_CIVILIANS = "magellan_civviescavs";
   public static final String MG_EVENT_MAKES_HERD_BASES = "makesHerdBases";
}
