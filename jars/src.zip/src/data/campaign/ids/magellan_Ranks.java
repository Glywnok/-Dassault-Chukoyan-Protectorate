package data.campaign.ids;

public class magellan_Ranks {

}
