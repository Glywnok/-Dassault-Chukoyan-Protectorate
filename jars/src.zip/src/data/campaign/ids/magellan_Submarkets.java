package data.campaign.ids;

public class magellan_Submarkets {
   public static final String SUBMARKET_MAGELLAN_OPEN = "dcp_magellan_open_market";
   public static final String SUBMARKET_MAGELLAN_IND_MIL = "dcp_magellan_ind_military";
}
