package data.campaign.ids;

public class dcp_DME_Entities {
   public static final String STATION_MINING_BREAKER = "dcp_DME_bladebreaker_mining";
   public static final String STATION_RESEARCH_BREAKER = "dcp_DME_bladebreaker_research";
   public static final String ORBITAL_HABITAT_BREAKER = "dcp_DME_bladebreaker_habitat";
   public static final String WEAPONS_CACHE_BREAKER = "dcp_DME_weapons_cache_breakers";
   public static final String WEAPONS_CACHE_SMALL_BREAKER = "dcp_DME_weapons_cache_small_breakers";
}
