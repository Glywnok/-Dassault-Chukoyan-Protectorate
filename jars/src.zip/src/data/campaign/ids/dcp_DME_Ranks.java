package data.campaign.ids;

public class dcp_DME_Ranks {
   //DME
   public static final String SMATTER_RESEARCHER = "dcp_DME_smatterresearch";
   public static final String POST_SNRI_REPRESENTATIVE = "dcp_DME_SNRIrep";
   public static final String POST_ARMS_RESEARCHER = "dcp_DME_armsengineer";

   //Magellan
   public static final String LORDREGENT = "dcp_magellan_lordregent";
}
