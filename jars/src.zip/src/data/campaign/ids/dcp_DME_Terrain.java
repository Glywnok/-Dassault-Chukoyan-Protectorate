package data.campaign.ids;

public class dcp_DME_Terrain {
   public static final String CORONA_SIGMA = "corona_sigma";
}
