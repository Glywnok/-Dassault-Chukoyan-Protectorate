package data.campaign.ids;

public class magellan_Industries {
   //Magellan
   public static final String MG_SKYTIGERHQ = "magellan_startigerhq";
}
