package data.campaign.ids;

public class dcp_DME_Conditions {
   public static final String SIGMARAD = "dcp_DME_sigmarad";
}
