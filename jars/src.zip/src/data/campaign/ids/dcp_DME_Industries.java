package data.campaign.ids;

public class dcp_DME_Industries {
   //DME
   public static final String SIXTHBUREAU = "dcp_DME_6emebureau";
   public static final String BBGUARDIAN = "dcp_DME_acolyte";
   public static final String SIGMASHIELD = "dcp_DME_sigmafield";

   //Magellan
   public static final String MG_SKYTIGERHQ = "dcp_magellan_startigerhq";
}
